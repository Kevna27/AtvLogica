#include <stdio.h>
#include <stdlib.h>

int main()
{
        int totalAlunos = 36;
    int A = 9 + 10 + 7;
    int B = 9 + 7 + 5;
    int C = 10 + 7 + 7;
    int AB = 9;
    int AC = 10;
    int BC = 7;
    int erraramTudo = 4;

    // Usar a f�rmula para encontrar o n�mero de alunos que acertaram todas as tr�s quest�es
    int ABC = A + B + C - AB - AC - BC + erraramTudo - totalAlunos;

    printf("N�mero de alunos que acertaram todas as tr�s quest�es: %d\n", ABC);

    return 0;
}
